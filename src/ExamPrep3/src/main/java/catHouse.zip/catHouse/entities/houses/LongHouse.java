package catHouse.entities.houses;

public class LongHouse extends BaseHouse{
    public LongHouse(String name) {
        super(name, 30);
    }
}
