package catHouse.entities.toys;

public class Ball extends BaseToy{

    public Ball(){
        super(1,10);
    }

}
