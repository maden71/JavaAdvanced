package JavaAdvanced.Exam.workout;

public class Main {
}
